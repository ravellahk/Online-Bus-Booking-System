<?php

  ?>
<html>
    <head>
        <title>Online Bus Reservation</title>
        <link rel="stylesheet" href="style.css">
        <style>
body  {
  background-image: url(https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcTmle4cXV9DJ-hCiDIYSFO4pjeIfGt2COP7lQ&usqp=CAU);
  background-size: cover;
  background-position: center;
  box-sizing: border-box;
  font-family: sans-serif;
}

.menu-bar{
    background: rgb(0,100,0);
    text-align: center;
}   

.menu-bar ul {
    display: inline-flex;
    list-style: none;
    color: #fff;
                
}
            
.menu-bar ul li {
    width: 120px;
    margin: 15px;
    padding: 15px;
                
} 
.menu-bar ul li a {
    text-decoration: none;
    color: #fff;
                
}
.active, .menu-bar ul li:hover
{
    background: #2bab0d;
    border-radius: 3px;
             
</style>
    </head>
    <body>
      <center><h1>OnLine Bus Reservation System</h1></center>
        
        <div class="menu-bar">
    <ul>
            <li class="active"><a href="index.php">Home</a></li>
            <li><a href="Adminlogin.php">Admin</a></li>
            <li><a href="AboutUs.php">About Us</a></li>
            <li><a href="ContactUs.php">Contact Us</a></li>



    </ul>
       </div>
            <center><h2>Manage Buses</h2>
                
        <?php include "../db-con.php";
                if(isset($_POST['submit'])){
                    $busname = $_POST['busname'];
                    $seats = $_POST['seats'];
                    $fromstop = $_POST['fromstop'];
                    $tostop = $_POST['tostop'];
                    $departuretime = $_POST['departuretime'];
                    $arrivaltime = $_POST['arrivaltime'];
                    $distance = $_POST['distance'];
                       
                        $query = "INSERT INTO managebuses(busname, totalseats, availableseats, fromstop, tostop, departuretime, arrivaltime, distance ) VALUES ('$busname', '$seats', '$seats', '$fromstop', '$tostop', '$departuretime', '$arrivaltime', '$distance' )";
                        if(!mysqli_query($con, $query)){
                            echo "INsert query failed";
                       
                    }
                }
                ?>
        
        <form action="" method="post">
            <table>
            
                <tr>
                <td>Bus Name:</td>
                <td>
                <input type="text" name="busname">
                </td>
                </tr>
                <tr>
                <td>From Stop:</td>
                <td>
                <input type="text" name="fromstop" >
                </td>
                </tr>
                <tr>
                <td>To Stop:</td>
                <td>
                <input type="text" name="tostop" >
                </td>
                </tr>
                <tr>
                <td>Total Seats:</td>
                <td>
                <input type="text" name="seats">
                </td>
                </tr>
                <tr>
                    <td>Departure time:</td>
                    <td>
                <input type="time" name="departuretime">
                    </td></tr>
                <tr><td>Arrival time:</td>
                <td><input type="time" name="arrivaltime">
                    </td></tr>
                <tr>
                <td>Distance:</td>
                <td>
                <input type="text" name="distance">
                </td>
                </tr>
                <tr><td><input type="submit" name="submit" value="save"></td>
                <td><input type="submit" name="Modify" value="Modify"></td>
                <td><input type="submit" name="Remove" value="Remove"></td>
                <td><input type="submit" name="Search" value="Search"></td><tr>
        </table>
                </form>
        <marquee> <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcRn2owwRLe9n30vAcmh3v31Tm6kjfuJ_t1A1w&usqp=CAU"> <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcTpDWnRPVovdQ8gNfqedpF12sI_GV7JbNTcJQ&usqp=CAU"> <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcRrpOBwAKOJO3ShiN-vTVMW_ponzakr2nItow&usqp=CAU"> <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcTyfdgyNDm0i91MKNcCV885tSTzf8QHldXQFg&usqp=CAU"> <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcSjbJv3uoIYDFKOAGcSKDFRdhVcogVN7fwkJg&usqp=CAU"> <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcQ1J3Wtabp2BAgbagJcwP5NpFETHnEFpywNQA&usqp=CAU"> <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcS3RclUHhdGuvdxlgTioBsIcJvOUR94fSJ-Cg&usqp=CAU"> </marquee>
    </body>
</html>