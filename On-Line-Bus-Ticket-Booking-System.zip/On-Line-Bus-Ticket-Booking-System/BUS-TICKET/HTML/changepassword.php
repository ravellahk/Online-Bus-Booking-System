<?php
session_start();
  ?>

<html>
    <head>
        <title>Online Bus Reservation</title>
        <link rel="stylesheet" href="style.css">
        <style>
body  {
  background-image: url(https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcTmle4cXV9DJ-hCiDIYSFO4pjeIfGt2COP7lQ&usqp=CAU);
  background-size: cover;
  background-position: center;
  box-sizing: border-box;
  font-family: sans-serif;
}

.menu-bar{
    background: rgb(0,100,0);
    text-align: center;
}   

.menu-bar ul {
    display: inline-flex;
    list-style: none;
    color: #fff;
                
}
            
.menu-bar ul li {
    width: 120px;
    margin: 15px;
    padding: 15px;
                
} 
.menu-bar ul li a {
    text-decoration: none;
    color: #fff;
                
}
.active, .menu-bar ul li:hover
{
    background: #2bab0d;
    border-radius: 3px;
             
</style>
    </head>
    <body>
        <?php 
           if(isset($_SESSION['id'])){
               
          ?>
        
      <center><h1>OnLine Bus Reservation System</h1></center>
        
        <div class="menu-bar">
    <ul>
            <li class="active"><a href="index.php">Home</a></li>
            <li><a href="Adminlogin.php">Admin</a></li>
            <li><a href="AboutUs.php">About Us</a></li>
            <li><a href="ContactUs.php">Contact Us</a></li>



    </ul>
       </div>
            <center><h2>Change Password</h2>
        
        <?php 
               include "../db-con.php ";
               if(isset($_POST['submit'])){
                   $old = $_POST['user_old_pass'];
                    $new = $_POST['user_New_pass'];
                    $conf = $_POST['user_conf_pass'];
                   $q = "SELECT password from login where id='".$_SESSION['id']."'";
                   $q=mysqli_query($con, $q);
                   $user_pass = mysqli_fetch_array($q)[0];
                   //print_r($user_pass);
                   if($old==$user_pass){
                       if($new == $conf){
                           $query = "UPDATE login SET password = '$new' WHERE id = '".$_SESSION['id']."'";
                            if(mysqli_query($con, $query)){
                                echo "<p style='color:green; weight: 300'>Your Password has been updated successfully.</p>";
                            }
                       }else{
                           echo "<p style='color:red'>Password and Confirm Password field must be same.</p>";
                       }
                   }else{
                       echo "<p style='color:red'>Please enter correct Password.</p>";
                   }
               }
               
                ?>
        <form action="" method="post">
            <table>
            <tr>
                <td>Old Password:</td>
                <td>
                <input type="password" name="user_old_pass">
                </td>
                </tr>
                <tr>
                <td>New Password:</td>
                <td>
                <input type="password" name="user_New_pass">
                </td>
                </tr>
                <tr>
                <td>Confirm Password:</td>
                <td>
                <input type="password" name="user_conf_pass">
                </td>
                </tr>
                <tr>
                <td>
                <input type="submit" name="submit" value="Submit">
                </td>
                </tr>
                
                
            </table>
            
        </form>
        </center>
        <marquee> <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcRn2owwRLe9n30vAcmh3v31Tm6kjfuJ_t1A1w&usqp=CAU"> <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcTpDWnRPVovdQ8gNfqedpF12sI_GV7JbNTcJQ&usqp=CAU"> <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcRrpOBwAKOJO3ShiN-vTVMW_ponzakr2nItow&usqp=CAU"> <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcTyfdgyNDm0i91MKNcCV885tSTzf8QHldXQFg&usqp=CAU"> <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcSjbJv3uoIYDFKOAGcSKDFRdhVcogVN7fwkJg&usqp=CAU"> <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcQ1J3Wtabp2BAgbagJcwP5NpFETHnEFpywNQA&usqp=CAU"> <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcS3RclUHhdGuvdxlgTioBsIcJvOUR94fSJ-Cg&usqp=CAU"> </marquee>
    <?php 
           }
        else{
            header("Location: signin.php");
            
        }
        ?>
    </body>
    
</html>