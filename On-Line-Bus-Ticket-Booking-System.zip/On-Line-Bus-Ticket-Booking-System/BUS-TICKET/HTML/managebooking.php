<?php

  ?>
<html>
    <head>
        <title>Online Bus Reservation</title>
        <link rel="stylesheet" href="style.css">
        <style>
body  {
  background-image: url(https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcTmle4cXV9DJ-hCiDIYSFO4pjeIfGt2COP7lQ&usqp=CAU);
  background-size: cover;
  background-position: center;
  box-sizing: border-box;
  font-family: sans-serif;
}

.menu-bar{
    background: rgb(0,100,0);
    text-align: center;
}   

.menu-bar ul {
    display: inline-flex;
    list-style: none;
    color: #fff;
                
}
            
.menu-bar ul li {
    width: 120px;
    margin: 15px;
    padding: 15px;
                
} 
.menu-bar ul li a {
    text-decoration: none;
    color: #fff;
                
}
.active, .menu-bar ul li:hover
{
    background: #2bab0d;
    border-radius: 3px;
             
</style>
    </head>
    <body>
      <center><h1>OnLine Bus Reservation System</h1></center>
        
        <div class="menu-bar">
    <ul>
            <li class="active"><a href="index.php">Home</a></li>
            <li><a href="Adminlogin.php">Admin</a></li>
            <li><a href="AboutUs.php">About Us</a></li>
            <li><a href="ContactUs.php">Contact Us</a></li>



    </ul>
       </div>
            <center><h2>Manage Booking</h2>
                <?php include "../db-con.php";
                if(isset($_POST['submit'])){
                    
                    $bookingid = $_POST['bookingid'];
                    $userid = $_POST['userid'];
                    $busid = $_POST['busid'];
                    
                    
                    $q = "SELECT userid FROM managebooking WHERE userid = '$userid'";
                    $q=mysqli_query($con, $q);
                   if(mysqli_num_rows($q)==0){
                       
                        $query = "INSERT INTO managebooking(bookingid, userid, busid) VALUES ('$bookingid', '$userid', '$busid')";
                        if(!mysqli_query($con, $query)){
                            echo "INsert query failed";
                        }
                       $sql="select * from managebooking where bookingid='".$bookingid."'AND userid='".$userid."'AND busid='".$busid."' limit 1";
                    
                    $result=mysqli_query($con, $sql);
                       $row = mysqli_fetch_assoc($result);
                       session_start();
                        $id = $row['id'];
                        $_SESSION['userid'] = $userid;
                        $_SESSION['id'] = $id;
                       header("Location: adminhome.php");
                       
                    }else{
                        echo "";
                    }
                }
                ?>
        
        <marquee> <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcRn2owwRLe9n30vAcmh3v31Tm6kjfuJ_t1A1w&usqp=CAU"> <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcTpDWnRPVovdQ8gNfqedpF12sI_GV7JbNTcJQ&usqp=CAU"> <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcRrpOBwAKOJO3ShiN-vTVMW_ponzakr2nItow&usqp=CAU"> <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcTyfdgyNDm0i91MKNcCV885tSTzf8QHldXQFg&usqp=CAU"> <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcSjbJv3uoIYDFKOAGcSKDFRdhVcogVN7fwkJg&usqp=CAU"> <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcQ1J3Wtabp2BAgbagJcwP5NpFETHnEFpywNQA&usqp=CAU"> <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcS3RclUHhdGuvdxlgTioBsIcJvOUR94fSJ-Cg&usqp=CAU"> </marquee>
    </body>
</html>